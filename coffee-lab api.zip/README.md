# Coffee Lab Admin API Documentation

Comprehensive guide to the Coffee Lab Admin Panel backend API, covering all available endpoints, data models, and usage examples.

## 🚀 Overview

The API is built with **Express.js** and uses a flat-file JSON database (`/data/*.json`) for persistence. It supports image uploads via `multer` and automatic image optimization using `sharp`.

- **Base URL**: `http://localhost:3000` (default)
- **Content Types**:
  - `application/json` for Orders and Coupons
  - `multipart/form-data` for Products and Blogs (due to image uploads)

---

## � Entities

The API manages the following entities:

- **Products**: `beans`, `machines`, `syrups`, `sauces`
- **Content**: `blogs`
- **Business**: `orders`, `coupons`

---

## 📡 API Endpoints

### 1. Generic Endpoints

Available for **ALL** entities.

#### Get All Records

`GET /:entity`

**Response:**

```json
[
  {
    "id": "A1b2C3d4",
    "slug": "example-item",
    "name": "Example Item",
    ...
  }
]
```

#### Get Single Record

`GET /:entity/:id_or_slug`

- **Params**: `id_or_slug` (The unique 8-char ID or the URL-friendly slug)

**Response:**

```json
{
  "id": "A1b2C3d4",
  "slug": "example-item",
  ...
}
```

#### Delete Record

`DELETE /:entity/:id_or_slug`

- **Behavior**: Deletes the record from JSON and permanently removes associated images from the `/uploads` directory.

**Response:**

```json
{ "message": "Deleted successfully" }
```

---

### 2. Products API

**Entities**: `beans`, `machines`, `syrups`, `sauces`
**Content-Type**: `multipart/form-data`

#### Create Product

`POST /:entity`

**Form Data Fields:**

- `name` (string, required)
- `description` (string)
- `price` (number)
- `inStock` (boolean: "true"/"false")
- `isFeatured` (boolean: "true"/"false")
- `discountPercentage` (number)
- `variants` (JSON string, e.g., `[{"size": "250g", "price": 500}]`)
- `images` (File[], max 5)
- **Machines Only**: `specifications`, `features` (JSON strings)
- **Beans/Syrups Only**: `cupping_notes` (comma-separated string)

**Example Request (cURL):**

```bash
curl -X POST http://localhost:3000/beans \
  -F "name=Ethiopia Yirgacheffe" \
  -F "price=1200" \
  -F "inStock=true" \
  -F "cupping_notes=Floral,Citrus" \
  -F "images=@/path/to/bean.jpg"
```

#### Update Product

`PUT /:entity/:id`

**Form Data Fields:**

- Include any fields from POST to update them.
- `existingImages` (JSON string): Array of image filenames to keep.
- `images` (File[]): New images to append.

---

### 3. Blogs API

**Entity**: `blogs`
**Content-Type**: `multipart/form-data`

#### Create Blog Post

`POST /blogs`

**Form Data Fields:**

- `title` (string, required)
- `content` (string, HTML allowed)
- `excerpt` (string)
- `category` (string)
- `author` (string)
- `image` (File, single)

**Behavior**: Automatically calculates `readTime` and sets `date` to current date.

#### Update Blog Post

`PUT /blogs/:id`

- Same fields as POST.
- New image upload replaces the existing one.

---

### 4. Orders API

**Entity**: `orders`
**Content-Type**: `application/json`

#### Create Order

`POST /orders`

**Body:**

```json
{
  "customerName": "Jane Doe",
  "email": "jane@example.com",
  "phone": "+8801700000000",
  "address": "Dhaka, Bangladesh",
  "items": [
    {
      "productId": "A1b2C3d4",
      "productName": "Ethiopia Yirgacheffe",
      "variant": "250g",
      "price": 1200,
      "quantity": 1
    }
  ],
  "totalAmount": 1200,
  "paymentMethod": "COD"
}
```

#### Update Order

`PUT /orders/:id`

**Body**: Any subset of the order object (e.g., status update).

```json
{ "status": "Shipped", "isPaid": true }
```

---

### 5. Coupons API

**Entity**: `coupons`
**Content-Type**: `application/json`

#### Data Model

| Field         | Type    | Description                                    |
| :------------ | :------ | :--------------------------------------------- |
| `code`        | String  | Unique code (e.g., "SAVE20"). Auto-uppercased. |
| `type`        | String  | `percentage` or `flat`.                        |
| `value`       | Number  | Amount or percentage value.                    |
| `isActive`    | Boolean | Whether the coupon can be used.                |
| `maxUses`     | Number  | Total times it can be redeemed.                |
| `currentUses` | Number  | Current redemption count.                      |
| `expiryDate`  | String  | Date string (YYYY-MM-DD).                      |
| `maxDiscount` | Number  | Cap for percentage discounts.                  |

#### Create Coupon

`POST /coupons`

**Body:**

```json
{
  "code": "WELCOME10",
  "type": "percentage",
  "value": 10,
  "isActive": true,
  "maxUses": 100,
  "expiryDate": "2026-12-31"
}
```

#### Update Coupon

`PUT /coupons/:id`

**Body**: Any subset of fields to update.

```json
{ "isActive": false }
```

---

## 🛠️ Setup & Development

1. **Install Dependencies**

   ```bash
   npm install
   ```

2. **Start Server**

   ```bash
   node index.js
   ```

   Server runs on `http://localhost:3000`.

3. **Data Storage**
   - JSON Data: `./data/{entity}.json`
   - Uploads: `./uploads/`

## ⚠️ Important Notes

- **Slug Generation**: Slugs are auto-generated from `name` (Products) or `title` (Blogs) on creation. They are immutable afterwards.
- **Image Deletion**: Deleting a product/blog permanently deletes its images from disk. This is irreversible.
- **Historical Orders**: Order items snapshot the product name/price at time of purchase. Changing a product's price later does not affect past orders.
